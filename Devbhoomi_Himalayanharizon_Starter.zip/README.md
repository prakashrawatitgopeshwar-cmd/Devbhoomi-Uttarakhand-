# Devbhoomi Himalayanharizon

Starter website for a bilingual Uttarakhand travel, culture, and cab-booking platform.

## Included
- Responsive Next.js App Router homepage
- Forest-green and earth-tone visual direction
- Home, Destinations, Explore & Plan, Cab Booking, Tour Packages, About, Login navigation
- Primary actions: Explore & Plan and Instant Book Cab
- Initial cab routes: Deghat → Delhi and Deghat → Chandigarh
- English/Hindi language toggle prototype (visual only)
- Safe `.env.example` with no credentials

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local` and add the Supabase URL and publishable key if needed.
4. Run `npm run dev` and open `http://localhost:3000`.

## Important status
This is a front-end starter, not a finished booking platform. Authentication, role approvals, trip planning persistence, driver matching, payments, admin controls, and production-grade Supabase RLS still need implementation and testing.

Never put Supabase secret/service-role keys in client-side code or commit them to GitHub.
