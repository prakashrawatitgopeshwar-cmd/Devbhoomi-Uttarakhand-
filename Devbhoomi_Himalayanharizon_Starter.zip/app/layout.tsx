import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Devbhoomi Himalayanharizon | Discover Uttarakhand",
  description:
    "Explore Uttarakhand destinations, culture, curated journeys and cab routes with Devbhoomi Himalayanharizon.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
