const destinations = [
  { name: "Auli", type: "Mountain escapes", mark: "❄", detail: "High Himalayan views and alpine meadows" },
  { name: "Jageshwar", type: "Heritage & spirituality", mark: "ॐ", detail: "Ancient stone temples among deodar trees" },
  { name: "Munsiyari", type: "Slow mountain travel", mark: "◈", detail: "Big mountain horizons and Kumaoni life" },
];

const interests = [
  { icon: "⌂", title: "Culture & Heritage", text: "Discover living traditions, local art, food and stories." },
  { icon: "↟", title: "Nature & Trails", text: "Find forest walks, mountain viewpoints and quiet escapes." },
  { icon: "✧", title: "Spiritual Journeys", text: "Explore sacred places with thoughtful travel planning." },
];

export default function HomePage() {
  return (
    <main>
      <div className="announcement">Pahadon ki parampara · Himalayan hospitality · Responsible travel</div>
      <header className="site-header">
        <a className="brand" href="#" aria-label="Devbhoomi Himalayanharizon home">
          <span className="brand-mark">ध</span>
          <span><strong>DEVBHOOMI</strong><small>HIMALAYANHARIZON</small></span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#home">Home</a>
          <a href="#destinations">Destinations</a>
          <a href="#explore">Explore &amp; Plan</a>
          <a href="#cab">Cab Booking</a>
          <a href="#packages">Tour Packages</a>
          <a href="#about">About</a>
        </nav>
        <div className="header-actions"><button className="language">हिंदी / EN</button><a className="login" href="#login">Login ↗</a></div>
      </header>

      <section className="hero" id="home">
        <div className="hero-art" aria-hidden="true">
          <div className="sun"></div><div className="mountain mountain-back"></div><div className="mountain mountain-mid"></div><div className="mountain mountain-front"></div>
          <div className="forest"></div>
          <div className="art-caption">THE HIMALAYAS · UTTARAKHAND</div>
        </div>
        <div className="hero-content">
          <p className="eyebrow"><span></span> A JOURNEY INTO THE SOUL OF THE MOUNTAINS</p>
          <h1>Discover Uttarakhand.<br /><em>Experience Its Soul.</em></h1>
          <p className="hero-copy">Explore destinations, plan your perfect mountain journey, discover curated tour packages and book your cab with confidence.</p>
          <div className="hero-buttons">
            <a className="button button-primary" href="#explore">Explore &amp; Plan <span>↗</span></a>
            <a className="button button-light" href="#cab"><span>⌁</span> Instant Book Cab</a>
          </div>
          <div className="hero-note"><span className="note-icon">✦</span><span><strong>Rooted in Uttarakhand</strong><small>Local stories. Thoughtful journeys.</small></span></div>
        </div>
        <div className="hero-bottom"><span>29° 35′ N — 79° 39′ E</span><span>THE LAND OF THE GODS</span><span>SCROLL TO EXPLORE ↓</span></div>
      </section>

      <section className="section destinations-section" id="destinations">
        <div className="section-heading">
          <div><p className="eyebrow">FIND YOUR KIND OF HIMALAYA</p><h2>Places that stay <em>with you.</em></h2></div>
          <a className="text-link" href="#explore">Explore all destinations <span>↗</span></a>
        </div>
        <div className="destination-grid">
          {destinations.map((place, index) => (
            <article className={`destination-card card-${index + 1}`} key={place.name}>
              <div className="destination-visual"><span className="visual-mark">{place.mark}</span><span className="card-number">0{index + 1}</span></div>
              <div className="destination-info"><p>{place.type}</p><h3>{place.name}</h3><span>{place.detail}</span><a href="#explore" aria-label={`Plan a trip to ${place.name}`}>↗</a></div>
            </article>
          ))}
        </div>
      </section>

      <section className="culture-section" id="about">
        <div className="culture-art"><div className="aipan-pattern">✳<br />✧<br />✳</div><span>OUR LIVING HERITAGE</span></div>
        <div className="culture-copy"><p className="eyebrow">MORE THAN A DESTINATION</p><h2>Feel the rhythm of<br /><em>the mountains.</em></h2><p>From age-old traditions and warm village welcomes to local flavours and craft, discover the Uttarakhand that lives beyond the postcards.</p><a className="button button-outline" href="#explore">Discover our culture <span>↗</span></a></div>
      </section>

      <section className="section explore-section" id="explore">
        <div className="section-heading"><div><p className="eyebrow">YOUR JOURNEY, YOUR WAY</p><h2>What calls <em>you?</em></h2></div><p className="heading-description">Start with what you love. We’ll help you shape the journey.</p></div>
        <div className="interest-grid">{interests.map((item) => <article className="interest-card" key={item.title}><span className="interest-icon">{item.icon}</span><h3>{item.title}</h3><p>{item.text}</p><a href="#planner">Build your journey ↗</a></article>)}</div>
        <div className="planner-banner" id="planner"><div><p className="eyebrow">LET THE MOUNTAINS CALL</p><h3>Your next story begins here.</h3><p>Choose your interests and start planning a journey that feels like yours.</p></div><a className="button button-primary" href="#cab">Start trip planning <span>↗</span></a></div>
      </section>

      <section className="cab-section" id="cab">
        <div><p className="eyebrow">YOUR ROAD INTO THE HIMALAYAS</p><h2>Good journeys begin<br /><em>with a trusted ride.</em></h2><p>Book a cab for our initial routes, with more destinations planned as local operations grow.</p></div>
        <div className="route-list"><a href="#cab-form"><span>01</span><strong>Deghat <i>→</i> Delhi</strong><span className="route-arrow">↗</span></a><a href="#cab-form"><span>02</span><strong>Deghat <i>→</i> Chandigarh</strong><span className="route-arrow">↗</span></a><p id="cab-form" className="route-note">Booking form and live availability will be connected in a later development phase.</p></div>
      </section>

      <section className="packages-section" id="packages"><p className="eyebrow">CURATED WITH LOCAL CARE</p><h2>Journeys with a <em>deeper meaning.</em></h2><p>Thoughtfully planned experiences shaped around the landscapes, culture and pace of Uttarakhand.</p><a className="button button-light" href="#explore">Explore tour packages <span>↗</span></a></section>

      <footer className="footer" id="login"><div className="brand footer-brand"><span className="brand-mark">ध</span><span><strong>DEVBHOOMI</strong><small>HIMALAYANHARIZON</small></span></div><p>Rooted in the mountains. Made for meaningful journeys.</p><div className="footer-links"><a href="#destinations">Destinations</a><a href="#explore">Plan a trip</a><a href="#cab">Cab booking</a><a href="#about">Our story</a><a href="#login">Login</a></div><small className="copyright">© 2026 Devbhoomi Himalayanharizon · Built with respect for Uttarakhand.</small></footer>
    </main>
  );
}
